//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var str2 = "hello";
print(2+2);
if(str2=="hello")
{
    print("hello friend");
    //print("hello friend", 1,2,3,4, separator : "...", terminator : "....");
}

print("hello friendS", 1,2,3,4, separator : "...");
var num = 10;
var num2 = 20;
print("result", (num+num2));
print("😀", separator : "🇨🇦", terminator : "123");
print("👍");
print("🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦🇨🇦");
var x : Int;
x = 10;
print("x =  ", x);

var y :  String?;
y = "hello";
if(y != nil)
{
    print("y = \(String(describing: y))");
}

else{
    print("xcode 👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎");
}

var z : Int?;
print("z = ", z);
if(z != nil)
{
    print("z = \(String(describing: z))");
}
    
else{
    print("xcode 👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎👎");
}
if let PI: Float = 3.14
{
    print("PI", PI);
}
let friends : [String] = ["LA", "Abhishek", "Akash", "Aman"];

// for loop

for frnds in friends
{
    print("hello", frnds);
}
var i = 1;

// while loop
while(i < 3)
{
    print("i = ", i );
    i = i+1;
}

i = 1;

// repeat loop
repeat
{
    print("i = ", i);
    i = i + 1;
}
    while (i<3);

switch (i) {
case 1:
    print("ONE");
    break;

case 2...10:
    print("between 2 and 10");
    break;
    
case 11..<20:
    print("between 11 and 20");
    break;
    
default:
    print("👊👊👊👊👊👊");
}

// switch with fallthrough

let coordinate = (10,20);
switch coordinate {
case (0,0):
    print("0  and  0");
    
    fallthrough; // countinue to next case without exiting or breaking
    
case (_,20):
    print("_  and  20");
    break;
    
case (10,_):
    print("10 and  _");
    break;
    

    
case (1...10, 10...20):
    print("10... and  ...20");
    break;
    
case (_,_):
    print("_ and  _");
    break;
    
default:
    print("👄");
}
// range print
let range = 1...5;
print(range);
print("\(range) contains 3", range.contains(3));
print("\(range) lower bound", range.lowerBound);
print("\(range) lower bound", range.upperBound);

