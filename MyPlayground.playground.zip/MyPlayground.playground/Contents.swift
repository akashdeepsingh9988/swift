//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var a = 0;
var b = 0;
func greet(message :  String)
{
    print(message)
}

greet(message: "hello world");

// add underscore for optional labels
//func add(_ n1: Int , _ n2 : Int) -> Int
func add(n1: Int , n2 : Int) -> Int
{
    let sum = n1+n2;
    return sum;
}

// labels are mandatory
var result = add(n1: 50, n2: 50)
print(result)

// function parms are let by default
func swap(j: Int, k : Int) -> (Int, Int)
{
  return (k , j)
}

// inout for changing lets values
func swap2(j: inout Int, k : inout Int)
{
    let temp = j;
    j = k;
    k = temp;
    print("j = \(j) , K =  \(k)")
}

(a,b) = swap(j: 10, k : 120)
print("a :\(a) , b : \(b)")
swap2(j: &a, k : &b)

// Double rate = 20 to set default value in func parameters to use default value if not provided

func dsp(num : Int...)
{
    var sum  = 0;
    for n in num
    {
        sum += n
    }
    print("sum : \(sum)")
}

dsp(num: 10,20,45,20,65)
dsp(num: 10)

// add array
func addArray(arrays: [Int]...) -> [Int]
{
    var a = arrays.count;
    
    var array1 = arrays[0]
    var array2 = arrays[1]
    var result = [Int]()
    
    if(array1.count == array2.count)
    {
        for i in 0..<array1.count{
            result.append(array1[i] + array2[i])
        }
        print("result after adding array : \(result) ")
    }
    return result;
}

var ar1 = [1,2,3,4,5]
var ar2 = [9,9,9,9,9]
// storing values by calling function
var rs = addArray(arrays: ar1, ar2)
print("result \(rs)")

// function as type
var addop : (Int, Int) -> Int = add

print("add op : \(addop(10,20))")

// function as parameter

func callAnother(someFunc : (Int, Int) -> Int, a: Int, b: Int)
{
    print("some func : \(someFunc(a, b))")
}

callAnother(someFunc: add, a: 5, b: 9)

// func as return type
func stepForward(_ input: Int) -> Int {
    return input + 1
}
func stepBackward(_ input: Int) -> Int {
    return input - 1
}

func counting (flag: Bool)-> (Int) -> Int
{
    return flag ? stepForward : stepBackward
}

var stepFunc  = counting(flag: true)
print("step func",stepFunc(3))
