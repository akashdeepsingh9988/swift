//: Playground - noun: a place where people can play
// Date July 13 2018
/*
 * Owner :  Akashdeep Singh
 */

import UIKit

var str = "Hello, playground"
print(str);

var greet = """
hello friends,
how are you doing
Cloudy weather....
boring class
Funny Friends
"""
//print(greet);

// emojis with unicode

let mood = "\u{1F496}" // 💖, Unicode scalar U+1F496
greet += mood;
print(greet, greet.count)

// printing all chars from string
var team = String()
team = "Croatia"

for i in team
{
    print(i);
}

// char operation append with team String variable
var initial : Character =  "J"
team.append(initial);
print(team);
team.append("Go Go Go");

// get count or length of string variable
print("Length" , team.count);

// get start index
print("start index of team", team[team.startIndex])

// get end index
//print("end index of team", team[team.endIndex])
print("end index of team", team[team.index(before: team.endIndex)])

// other

print("some char", team[team.index(after : team.startIndex)])
print("4th char", team[team.index(team.startIndex, offsetBy: 3)])

// from end
print("6th char from end", team[team.index(team.endIndex, offsetBy : -5)])
var idx = team.index(team.endIndex, offsetBy : -5)

print("\(team[idx])")

// for and terminator
for index in greet.indices {
    print("\(greet[index]) ", terminator: "_")
}

for (index, value) in team.enumerated()
{
    print("index : ", index,  "value : ", value);
}

// insert and remove from string
team.insert("!", at: team.endIndex)
print(team);

// insert full string  with contents of
team.insert(contentsOf : "⚽️", at: team.endIndex)

// get index of and storing end index if its not available
var index = team.index(of : "J") ?? team.endIndex
print("index : ", index);

// remove character from particular indexs

team.remove(at: index)

// remove subrange
team.removeSubrange(team.startIndex..<index)
team.removeSubrange(team.startIndex...index)

// get substring from string

var indexW = team.index(of : "W") ?? team.startIndex
var win  = team[indexW..<index]

win = win[win.startIndex...index]  // get last index by offset
print(win)

// uppercased
print(team.uppercased())

// lowercased
 print(team.lowercased())

// caps
print(team.capitalized)

/**************************************************************************************************************************/

// new string and operation
var grade : String?
grade = "A+"
let finalGrade = grade ?? "F"
print(finalGrade);



/*******************************************************************************************/
